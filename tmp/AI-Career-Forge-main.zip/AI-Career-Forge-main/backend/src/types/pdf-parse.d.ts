// Tell TypeScript that the 'pdf-parse' module exists, even without explicit types.
// This will allow importing it without errors, treating it essentially as 'any'.
declare module 'pdf-parse'; 